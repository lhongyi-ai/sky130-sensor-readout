#!/usr/bin/env python3
"""Install the runtime-only fix on an intact 1.0.4 package (Python 3.6+)."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import sys
import uuid

HERE=Path(__file__).resolve().parent
BASE_MANIFEST='825f6005b0738acda1358c6c8455e3be821f7da650c26aefcd38fc132d79c340'
FILES=('run.py','p1_run.sh','runtime_patch.json','package_manifest.json')

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def verify_package(root,manifest):
    for name,digest in manifest['files'].items():
        relative=Path(name)
        if relative.is_absolute() or '..' in relative.parts:
            raise ValueError('Invalid manifest path: '+name)
        path=root/relative
        if not path.is_file() or path.is_symlink() or sha(path)!=digest:
            raise ValueError('Package file changed or missing: '+name)

def atomic_copy(source,destination):
    temp=destination.with_name(destination.name+'.p1tmp_'+uuid.uuid4().hex)
    try:
        with temp.open('xb') as stream:
            stream.write(source.read_bytes())
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(str(temp),str(destination))
    finally:
        if temp.exists(): temp.unlink()

def install(root):
    root=root.resolve()
    patch=json.loads((HERE/'patch_manifest.json').read_text())
    if set(patch['payload'])!=set(FILES):
        raise ValueError('Unexpected patch payload')
    for name,digest in patch['payload'].items():
        if sha(HERE/'payload'/name)!=digest:
            raise ValueError('Patch checksum mismatch: '+name)
    manifest_path=root/'package_manifest.json'
    current=json.loads(manifest_path.read_text())
    if sha(manifest_path)==patch['payload']['package_manifest.json']:
        verify_package(root,current)
        print('P1_RUNTIME_PATCH_ALREADY_APPLIED: 1.0.4p1')
        return
    if sha(manifest_path)!=BASE_MANIFEST:
        raise ValueError('This fix requires the original basic_design_v1_0_4 package manifest')
    verify_package(root,current)
    for name in ['p1_run.sh','runtime_patch.json']:
        if (root/name).exists() or (root/name).is_symlink():
            raise ValueError('Unmanaged file exists; preserve for review: '+name)
    backup=root/'patch_backups'/'v1_0_4p1'
    if backup.exists():
        raise ValueError('Previous patch backup exists; preserve it and report this message')
    backup.mkdir(parents=True)
    for name in ['run.py','package_manifest.json']:
        shutil.copy2(str(root/name),str(backup/name))
    written=[]
    try:
        # The package manifest is the last file replaced, after all payloads.
        for name in FILES:
            atomic_copy(HERE/'payload'/name,root/name)
            written.append(name)
        verify_package(root,json.loads(manifest_path.read_text()))
    except Exception:
        for name in reversed(written):
            if (backup/name).exists(): atomic_copy(backup/name,root/name)
            else: (root/name).unlink()
        raise
    print('P1_RUNTIME_PATCH_APPLIED: 1.0.4p1')
    print('Existing site.json, cells, created.txt and runs preserved.')
    print('Next, in the same configured Linux terminal:')
    print('bash p1_run.sh run --group passives --retry')

if __name__=='__main__':
    try:
        if len(sys.argv)!=2: raise ValueError('Usage: install.py /path/to/basic_design_v1_0_4')
        install(Path(sys.argv[1]))
    except Exception as error:
        print('P1_RUNTIME_PATCH_STOPPED: '+str(error),file=sys.stderr)
        sys.exit(1)
