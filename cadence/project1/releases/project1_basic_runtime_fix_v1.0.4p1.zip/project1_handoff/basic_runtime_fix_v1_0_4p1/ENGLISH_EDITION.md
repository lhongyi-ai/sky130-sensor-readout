# English Publication Edition

This archive is an English translation of `project1_basic_runtime_fix_v1.0.4p1.zip` from the 2026-09-13 project checkpoint.

Original archive SHA-256: `3275426e6a9a8ebd5b62ed302b81a3674d1d249f8c6742ae40f98c5a0bac65ea`.

Documentation, messages, filenames, and package integrity bindings were translated or refreshed. Numerical circuit parameters and measurement payloads retain their original values. This translated archive has not been executed at the school; original school results refer to the original package bytes. Translated runtime patches require the corresponding English base package. Preserve any existing school installation and use the original locally retained packages for that installation.
