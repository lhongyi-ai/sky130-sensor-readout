# English Publication Edition

This archive is an English translation of `project1_m0_setup_v0.1.0.zip` from the 2026-09-13 project checkpoint.

Original archive SHA-256: `6559d00784f08bc685adb9cbe7b4f9bb8ac8ec42526087c0e6a07c4532928050`.

Documentation, messages, filenames, and package integrity bindings were translated or refreshed. Numerical circuit parameters and measurement payloads retain their original values. This translated archive has not been executed at the school; original school results refer to the original package bytes. Translated runtime patches require the corresponding English base package. Preserve any existing school installation and use the original locally retained packages for that installation.
