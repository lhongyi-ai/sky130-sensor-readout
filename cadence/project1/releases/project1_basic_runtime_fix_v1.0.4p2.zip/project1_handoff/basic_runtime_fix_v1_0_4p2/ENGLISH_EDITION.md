# English Publication Edition

This archive is an English translation of `project1_basic_runtime_fix_v1.0.4p2.zip` from the 2026-09-13 project checkpoint.

Original archive SHA-256: `99cf2f7774db4de0d2d6b13f97fb32bea4f17877d7ceed2edb1769cddb7cf9d8`.

Documentation, messages, filenames, and package integrity bindings were translated or refreshed. Numerical circuit parameters and measurement payloads retain their original values. This translated archive has not been executed at the school; original school results refer to the original package bytes. Translated runtime patches require the corresponding English base package. Preserve any existing school installation and use the original locally retained packages for that installation.
