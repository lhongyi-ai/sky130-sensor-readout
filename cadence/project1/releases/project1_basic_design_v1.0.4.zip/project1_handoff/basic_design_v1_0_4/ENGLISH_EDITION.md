# English Publication Edition

This archive is an English translation of `project1_basic_design_v1.0.4.zip` from the 2026-09-13 project checkpoint.

Original archive SHA-256: `ed8fb1d585a37673f0a4452fe274ad350bcea112a6f6b63c4252dab64ebfbbcd`.

Documentation, messages, filenames, and package integrity bindings were translated or refreshed. Numerical circuit parameters and measurement payloads retain their original values. This translated archive has not been executed at the school; original school results refer to the original package bytes. Translated runtime patches require the corresponding English base package. Preserve any existing school installation and use the original locally retained packages for that installation.
