# English Publication Edition

This archive is an English translation of `project1_basic_design_v1.0.0.zip` from the 2026-09-13 project checkpoint.

Original archive SHA-256: `0d0a62eab653a2a4f7a31ff51e5fbf5d7dd95423ed83620c27b35d091e094bc4`.

Documentation, messages, filenames, and package integrity bindings were translated or refreshed. Numerical circuit parameters and measurement payloads retain their original values. This translated archive has not been executed at the school; original school results refer to the original package bytes. Translated runtime patches require the corresponding English base package. Preserve any existing school installation and use the original locally retained packages for that installation.
