# v1.0.1: Fix the Missing PAS CDF Initialization

In v1.0.0, the user received `PasCdfCommitValue: failed to find valid initialization data!` during the `fingers` callback of the first MOS instance (M8). The generator had not executed the process CDF's `formInitProc`; this was neither a user loading-path error nor a Spectre simulation error.

Change: after obtaining the instance CDF, call its `formInitProc(cdfgData)` first. Initialization and subsequent callbacks share dynamically scoped `cdfgData/cdfgForm`; reapply the target sizes before executing parameter callbacks. Any initialization or callback error still stops execution immediately and preserves logs; geometry checks must not be bypassed.

Reference: [Cadence's explanation of the same PasCdfCommitValue error](https://community.cadence.com/cadence_technology_forums/f/custom-ic-skill/41963/get-error-pascdfcommitvalue-while-refreshing-cdf-using-abconvertcomponentparams-il). This revision addresses the identified omission. The school PDK is unavailable locally, so on-site validation must still determine whether initialization requires additional process-form context.

To retain the v1.0.0 failure state, the new OTA is named **`p1b_ota_legacy_r1`**. Testbench XOTA references are updated accordingly. The old `p1b_ota_legacy` is not read, deleted, or overwritten. This failure occurred while creating the first MOS, before testbench creation began. If a testbench with the same name unexpectedly exists, protection logic stops execution rather than overwriting it.

## Steps after uploading

Upload the new ZIP to `~/cadence_skywater/`. In the Linux terminal, run:

```bash
cd ~/cadence_skywater
unzip -n project1_basic_design_v1.0.1.zip
cd project1_handoff/basic_design_v1_0_1
python3 run.py prepare
```

Copy the entire printed `p1bRoot=... load(...)` line into the Cadence CIW and press Enter. Use the command printed from the **new directory**; do not load `create.il` from the old directory again.

The success indicator is `P1B_ALL_CREATED`. After it appears, run the following in the new Linux directory:

```bash
python3 run.py run --group passives
```

If an error remains, do not run simulations yet. Return the CIW error text and the new directory's `cdf_values.tsv` and `create_status.txt`. `cdf_values.tsv` now records the actual `formInitProc` before initialization, preserving diagnostics even if initialization fails. There is no need to delete the old directory or modify the process library.
