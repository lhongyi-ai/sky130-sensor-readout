# English Publication Edition

This archive is an English translation of `project1_basic_design_v1.0.1.zip` from the 2026-09-13 project checkpoint.

Original archive SHA-256: `e01a2939979df8f97c5993c20d475cb50af9eaa9e5eebd1c74872c27d77f2b45`.

Documentation, messages, filenames, and package integrity bindings were translated or refreshed. Numerical circuit parameters and measurement payloads retain their original values. This translated archive has not been executed at the school; original school results refer to the original package bytes. Translated runtime patches require the corresponding English base package. Preserve any existing school installation and use the original locally retained packages for that installation.
