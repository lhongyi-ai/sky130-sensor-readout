# English Publication Edition

This archive is an English translation of `project1_basic_runtime_fix_v1.0.4p3.zip` from the 2026-09-13 project checkpoint.

Original archive SHA-256: `25a7b8b6dc780b65e1dd41c4aee47adb923ed46eba5729a36abf690849aa09b5`.

Documentation, messages, filenames, and package integrity bindings were translated or refreshed. Numerical circuit parameters and measurement payloads retain their original values. This translated archive has not been executed at the school; original school results refer to the original package bytes. Translated runtime patches require the corresponding English base package. Preserve any existing school installation and use the original locally retained packages for that installation.
