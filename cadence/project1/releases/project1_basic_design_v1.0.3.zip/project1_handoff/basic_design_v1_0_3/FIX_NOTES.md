# v1.0.3: Define Migration Sizes from Actual CDF Logs

The returned `p1_m8_diagnose.txt` completed normally, with both RESULT and FINAL_SAVE equal to (t). W remained 7.22005 µm after initialization and the fingers and l callbacks. The fw callback adjusted w/fw to 7.22 µm, which was also the final database readback. L=0.8 µm, fingers=1, and m=1 remained correct. The diagnostic did not run a simulation.

This revision does not change the size-check tolerance. It explicitly freezes migration sizes: each MOS width is rounded to 0.01 µm while original lengths, ports, and parallel instances are retained. See `device_size_mapping.md` and `size_mapping.json` for individual changes; the largest relative width change is below 0.05%. This is an explicit migration-design choice, **not** a conclusion from a single M8 sample that the process minimum grid is 0.01 µm. Other device callbacks still require strict checking, and complete performance must be resimulated rather than assumed unaffected.

The original OTA source and ngspice evidence are unchanged. The Cadence comparison explicitly identifies size adaptation and model-version differences. The new OTA is named `p1b_ota_legacy_r3`; old OTA and diagnostic cells are retained. If another size mismatch occurs, the script reports requested and actual values directly in the CIW and logs and saves the partial schematic instead of leaving only an empty cell.

## Instructions

Upload `project1_basic_design_v1.0.3.zip` to `~/cadence_skywater/`, then run the following in the Linux terminal:

```bash
cd ~/cadence_skywater
unzip -n project1_basic_design_v1.0.3.zip
cd project1_handoff/basic_design_v1_0_3
python3 run.py prepare
```

Paste the complete newly printed `p1bRoot=... load(...)` line into the Cadence CIW. Only after `P1B_ALL_CREATED` appears should the following be run in this new Linux directory:

```bash
python3 run.py run --group passives
```

Do not reload the old directory. If a new error occurs, return the CIW output and the new directory's `cdf_values.tsv` and `create_status.txt`. Old cells need not be deleted. Local tests and package checks do not establish successful execution of the new package in the school's Cadence environment.
