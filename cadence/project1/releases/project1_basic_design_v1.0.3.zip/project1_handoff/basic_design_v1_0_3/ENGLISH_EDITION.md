# English Publication Edition

This archive is an English translation of `project1_basic_design_v1.0.3.zip` from the 2026-09-13 project checkpoint.

Original archive SHA-256: `155a27221dcdb35e39461b9be039ef2e50608b3834162ef7b7a22d06a6b9a5f0`.

Documentation, messages, filenames, and package integrity bindings were translated or refreshed. Numerical circuit parameters and measurement payloads retain their original values. This translated archive has not been executed at the school; original school results refer to the original package bytes. Translated runtime patches require the corresponding English base package. Preserve any existing school installation and use the original locally retained packages for that installation.
