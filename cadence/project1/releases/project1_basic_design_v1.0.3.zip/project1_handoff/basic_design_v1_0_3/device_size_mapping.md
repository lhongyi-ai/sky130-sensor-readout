# Original dimensions and Cadence migration dimensions

The original source is unchanged. The widths below are explicitly selected migration dimensions; 0.01 µm is not a minimum process grid inferred from the single M8 sample. All callbacks and exported netlists must still strictly match these target values.

| Device | Original W / µm | Migrated W / µm | Difference / µm | Relative change |
|---|---:|---:|---:|---:|
| M8 | 7.22005 | 7.22 | -0.00005 | -0.000693% |
| M9 | 7.22005 | 7.22 | -0.00005 | -0.000693% |
| M10 | 8.08605 | 8.09 | 0.00395 | 0.048850% |
| M1 | 16.83798 | 16.84 | 0.00202 | 0.011997% |
| M2 | 16.83798 | 16.84 | 0.00202 | 0.011997% |
| M3A | 25 | 25 | 0.00 | 0.000000% |
| M3B | 25 | 25 | 0.00 | 0.000000% |
| M4A | 25 | 25 | 0.00 | 0.000000% |
| M4B | 25 | 25 | 0.00 | 0.000000% |
| M5 | 25.8754 | 25.88 | 0.0046 | 0.017778% |
| M6 | 8.83907427041 | 8.84 | 0.00092572959 | 0.010473% |
| M7 | 72.2005 | 72.2 | -0.0005 | -0.000693% |

Only the 7.22 µm width of M8 has school CDF diagnostic evidence; other instances still require validation of this package on Linux. The maximum relative width adjustment is below 0.05%, which does not establish that performance differences have been verified. Comparisons between the old ngspice results and new Cadence results must account for both this mapping table and model-version differences.
