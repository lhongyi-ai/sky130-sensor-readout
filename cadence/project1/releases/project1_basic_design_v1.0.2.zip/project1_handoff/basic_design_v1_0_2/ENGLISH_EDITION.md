# English Publication Edition

This archive is an English translation of `project1_basic_design_v1.0.2.zip` from the 2026-09-13 project checkpoint.

Original archive SHA-256: `8a9e5371bfef8ec1c2b0193f5ade85b9c858a1abbd77a23a038bfcfdb3710f6c`.

Documentation, messages, filenames, and package integrity bindings were translated or refreshed. Numerical circuit parameters and measurement payloads retain their original values. This translated archive has not been executed at the school; original school results refer to the original package bytes. Translated runtime patches require the corresponding English base package. Preserve any existing school installation and use the original locally retained packages for that installation.
