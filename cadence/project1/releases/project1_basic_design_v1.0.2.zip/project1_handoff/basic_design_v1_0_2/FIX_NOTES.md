# v1.0.2: Fix SKILL Parameter Type Detection

Running v1.0.1 produced `eval: undefined function - flonump`. The original script used a nonexistent function when writing CDF parameters back. This was a script error, not a user-operation error. Execution order indicates that this run passed the initialization and parameter-callback stages, but it does not establish that all MOS parameters were correct.

The script now uses SKILL `type()`: `string`→database string, `fixnum`→int, `flonum`→float, and t/nil→boolean. Integer detection is handled consistently. Before creating any cell, a self-check runs in real SKILL for strings, integers, floating-point numbers, and booleans; success prints `P1B_TYPE_CHECK_PASS`.

Reference: [type/fixnum/flonum in Cadence's official example](https://community.cadence.com/cadence_technology_forums/f/custom-ic-skill/36678/pcell-instance-inside-pcell-callback-issues/1349357). Local checks cannot replace actual execution in the school's Cadence environment.

The new OTA is named **`p1b_ota_legacy_r2`**, and all testbench references are updated. The old `p1b_ota_legacy` and `p1b_ota_legacy_r1` are not read, overwritten, or deleted, preserving both interrupted runs. Initial generation always starts with the OTA, so testbenches had not yet been generated when this error occurred. Existing testbenches with matching names still trigger the protection check and stop execution.

## Steps after uploading

Upload the new ZIP to `~/cadence_skywater/`, then run the following in the Linux terminal:

```bash
cd ~/cadence_skywater
unzip -n project1_basic_design_v1.0.2.zip
cd project1_handoff/basic_design_v1_0_2
python3 run.py prepare
```

Copy the entire newly printed `p1bRoot=... load(...)` line from the terminal into the Cadence CIW and press Enter. Do not use the load command from the old directory.

`P1B_TYPE_CHECK_PASS` should appear first, followed by `P1B_ALL_CREATED` once creation is complete. Only after the latter appears may the following be run in the new directory:

```bash
python3 run.py run --group passives
```

If a new error occurs, retain the CIW error text and the new directory's `cdf_values.tsv` and `create_status.txt`. Do not delete or reload the old versions.

## Fix history

v1.0.0 encountered `PasCdfCommitValue: failed to find valid initialization data!` during the M8 fingers callback. v1.0.1 added and logged instance-CDF formInitProc initialization; actual execution then exposed the type-detection error fixed here. v1.0.2 retains the initialization change. Geometry readback, exported-netlist review, and real simulation gates have not been relaxed.
