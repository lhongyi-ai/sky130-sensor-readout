# English Publication Edition

This archive is an English translation of `project1_probe_v1.0.0.zip` from the 2026-09-13 project checkpoint.

Original archive SHA-256: `54c54254d42c04c90fc0d967f10a2bc8ba8585b762063335c3ebc40353d36925`.

Documentation, messages, filenames, and package integrity bindings were translated or refreshed. Numerical circuit parameters and measurement payloads retain their original values. This translated archive has not been executed at the school; original school results refer to the original package bytes. Translated runtime patches require the corresponding English base package. Preserve any existing school installation and use the original locally retained packages for that installation.
