# project1 Environment Probe Package v1.0.0

This is the first probe package. It collects environment and device metadata without creating schematics, running simulations, or modifying project1, the PDK, or licenses. Reports are generated only inside this package's directory. Linux must already provide Python 3.6 or newer; if unavailable, stop and report it rather than installing software.

## 1. Upload

Use the school's Open OnDemand file page to upload `project1_probe_v1.0.0.zip` to:

```text
~/cadence_skywater/
```

Do not upload inside the `project1` library directory. Your newly created library remains intact.

## 2. Extract in a Linux terminal

Open Terminal on the school's Linux desktop and copy and run these three lines:

```bash
cd ~/cadence_skywater
unzip -n project1_probe_v1.0.0.zip
cd project1_handoff/probe
```

The ZIP already contains the `project1_handoff/probe/` directory structure. `-n` prevents overwriting existing files. If unzip is unavailable, extract through the file page or desktop archive manager, confirm that its `run.sh` is in the directory above, and enter that directory.

## 3. Run the terminal probe

```bash
bash run.sh probe
```

This usually finishes within one minute. It prints “Terminal probe complete. This is not a simulation pass.” and a complete `load("...")` line.

**Copy the actual load line printed by this run**, not a line from someone else's screenshot. Its path is generated from your account and this run's identifier.

If it reports “Python 3 must already be installed on Linux”, return that message. Do not modify the school's startup scripts yourself.

## 4. Run the probe in the main Cadence window

1. Start or return to Virtuoso using your existing school entry point; a new Virtuoso instance is not needed.
2. Find the main window (CIW) with **Virtuoso / Log** in its title. This is neither Library Manager nor the Linux Terminal.
3. Paste the entire `load(...)` command from the previous step into the command field at the bottom of that window and press Enter.
4. Wait for the log to display **`PROJECT1_PROBE_COMPLETE`**.

No new schematic will appear; this is expected. The script only reads existing project1 cells, the technology association, device CDF, symbol ports, and the current tool environment. CDF-declared ranges may be incomplete. Unspecified legal dimensions and multiplier semantics still need validation in the next stage; PCell callbacks are not executed to guess them.

If an error appears, retain the CIW error text (a screenshot is acceptable) and proceed to collect the partial report. Do not reload the same run file. To retry the probe, begin again at step 3; a new identifier will be generated and earlier reports retained.

## 5. Return to the same Linux terminal to collect results

```bash
bash run.sh collect
```

The collector uses the SKY130 libraries actually loaded by Virtuoso to inspect model/rule paths and prints the full path of a return ZIP whose name begins with `project1_report_`.

In the Open OnDemand file page, navigate to:

```text
~/cadence_skywater/project1_handoff/probe/
```

Download the newly generated **project1_report_…zip** and upload it back to this Codex task. Return the report ZIP, not the original probe package. If the CIW reported an error, include the error text or a screenshot.

## 6. Interpret the report

| Status | Meaning |
|---|---|
| METADATA_COLLECTED_REQUIRES_REVIEW | Core metadata collection is complete and must guide adaptation; this does not mean simulation succeeded |
| PARTIAL_REPORT | The Cadence probe is incomplete or project1/the technology is unconfirmed; return the ZIP anyway |
| FOUND_NOT_EXECUTED | An executable was found; license, model, and functional availability have not been established |
| NOT_ON_THIS_PATH | Not found on this session's path; this does not prove it is uninstalled |
| NOT_RUN / NOT_TESTED / NOT_QUALIFIED | The corresponding item has not been validated in an actual run |

Scanning has limits on depth, file count, and size. Failure to find models, statistical entry points, or rules does not immediately establish their absence; targeted inspection of actual paths follows report review.

If `active_run.json` cannot be found, step 3 has not completed successfully in this directory. Return to step 3.

If project1 is absent from the current library list, the package will not create or modify the library. Return the report so the issue can be investigated.

## What happens after the report is returned?

Codex will check standard/low-threshold MOS devices, MIM capacitors, resistors, statistical models, standard-cell libraries, and tool capabilities, then prepare an adapted design package. The second package will contain `tb_nmos_dc`, OTA schematic generation, simulation, and subsequent-stage entry points.

The original digital macro uses `sky130_fd_sc_hd`. If the school provides only a different standard-cell library, it will not be silently substituted. Missing software libraries, unavailable process rules, and circuit-performance failures are treated separately.

This package does not collect account passwords, license environment variables, terminal history, or complete PDK/rule files. The return package uses a fixed file allowlist. Actual library paths and the names of your project1 cells are included to avoid overwriting and support adaptation.

## Local validation scope

Before release, checks covered Python/Shell, report collection in an isolated simulated environment, missing-input handling, package completeness, and static SKILL parenthesis/string structure. **Virtuoso SKILL has not been executed locally; real SKILL APIs, PDK metadata, and Spectre version queries remain subject to this Linux run.**
